﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Dolgozat_Ötvös_Ákos
{
    internal class Fuvar
    {
        int taxiId;
        DateTime indulas;
        int idoTartam;
        float tavolsag;
        float vitelDij;
        float borravalo;
        string fizetesMod;

        public Fuvar(int taxiId, DateTime indulas, int idoTartam, float tavolsag, float vitelDij, float borravalo, string fizetesMod)
        {
            this.taxiId = taxiId;
            this.indulas = indulas;
            this.idoTartam = idoTartam;
            this.tavolsag = tavolsag;
            this.vitelDij = vitelDij;
            this.borravalo = borravalo;
            this.fizetesMod = fizetesMod;
        }

        public int TaxiId { get => taxiId;}
        public DateTime Indulas { get => indulas; }
        public int IdoTartam { get => idoTartam; }
        public float Tavolsag { get => tavolsag; }
        public float VitelDij { get => vitelDij; }
        public float Borravalo { get => borravalo; }
        public string FizetesMod { get => fizetesMod;   }
    }
}
