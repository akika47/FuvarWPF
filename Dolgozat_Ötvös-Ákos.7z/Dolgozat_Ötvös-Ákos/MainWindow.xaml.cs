﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dolgozat_Ötvös_Ákos
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<Fuvar> fuvarAdatok = new List<Fuvar>();
        public MainWindow()
        {

            InitializeComponent();
            using (StreamReader sr = new("fuvar.csv"))
            {
                sr.ReadLine()!.Skip(1);

                while (!sr.EndOfStream)
                {
                    string[] sor = sr.ReadLine()!.Split(";");

                    fuvarAdatok.Add(new Fuvar(
                        int.Parse(sor[0]),
                        DateTime.Parse(sor[1]),
                        int.Parse(sor[2]),
                        float.Parse(sor[3]),
                        float.Parse(sor[4]),
                        float.Parse(sor[5]),
                        sor[6]));

                }
            }

            foreach (var item in fuvarAdatok)
            {
                cbxtaxiId.Items.Add(item.TaxiId);
            }
        }


        private void feladat3_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"{fuvarAdatok.Count} fuvar");
        }

        private void feladat4_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(cbxtaxiId.SelectedItem.ToString());

            MessageBox.Show($"{fuvarAdatok.Count(x => x.TaxiId == id)} fuvar alatt: {fuvarAdatok.Where(x => x.TaxiId == id).Sum(x => x.VitelDij + x.Borravalo)}");
        }

        private void feladat5_Click(object sender, RoutedEventArgs e)
        {
            //fuvarAdatok.GroupBy(x => x.FizetesMod).ToList().ForEach(x => MessageBox.Show($"{x.Key}: {x.Count()} fuvar")) ;
            Dictionary<string, int> fizetesiModok = fuvarAdatok.GroupBy(x => x.FizetesMod).ToDictionary(x => x.Key, x => x.Count());
            foreach (var item in fizetesiModok)
            {
                lb5feladat.Items.Add(item);
            }



        }

        private void feladat6_Click(object sender, RoutedEventArgs e)
        {
            double osszesUt = Math.Round(fuvarAdatok.Sum(x => x.Tavolsag)*1.6,2);
            MessageBox.Show($"{osszesUt} km");
        }

        private void feladat7_Click(object sender, RoutedEventArgs e)
        {
            double leghosszabFuvar = 0;
            int idotartam = 0;
            string taxiId;
            double vitelDij;


            foreach (var item in fuvarAdatok)
            {
              if( item.Tavolsag > leghosszabFuvar)
                {
                    leghosszabFuvar = item.Tavolsag;
                }  
            }

             ;


                lb7feladat.Items.Add(fuvarAdatok.Where(x => x.Tavolsag == leghosszabFuvar).Select(x => x.IdoTartam));
        }
    }
}
